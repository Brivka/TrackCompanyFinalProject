﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;


namespace BL
{
    public class DriverBL
    {
        
        public static List<DriverDTO> GetDrivers()
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
                return CONVERTERS.DriverConverter.ConvertAllDriversToDTo(db.Drivers.ToList());
        }


        public static Driver GetDriveOfId(int id)
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
                return db.Drivers.Where(w => w.IdDriver == id).First();
        }


        public static bool AddDriver(DriverDTO Driver)
        {
            try
            {
                using (finalProjectDBEntities db = new finalProjectDBEntities())
                {
                    db.Drivers.Add(CONVERTERS.DriverConverter.ConvertDriveToDAL(Driver));
                    db.SaveChanges();
                }
                return true;

            }
            catch (Exception)
            {

                return false;
            }
           
        }

        public static bool Getdrivers(string email, string password)
        {
            return false;
        }

        public static void DeleteDriver(DriverDTO Driver)
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
                db.Drivers.Remove(CONVERTERS.DriverConverter.ConvertDriveToDAL(Driver));
                db.SaveChanges();
            }
        }


        public static DriverDTO UpdateDrive(DriverDTO Driver)
        {
            try
            {
                using (finalProjectDBEntities db = new finalProjectDBEntities())
                {
                    Driver newdrive = CONVERTERS.DriverConverter.ConvertDriveToDAL(Driver);
                    db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver).firstNameDriver = newdrive.firstNameDriver;
                    db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver).lastNameDriver = newdrive.lastNameDriver;
                    db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver).phoneDriver = newdrive.phoneDriver;
                    db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver).emailDriver = newdrive.emailDriver;
                    db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver).addressDriver = newdrive.addressDriver;
                    db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver).containInCar = newdrive.containInCar;
                    db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver).passwordDriver = newdrive.passwordDriver;
                    db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver).trustPasswordDriver = newdrive.trustPasswordDriver;
                    /* dr.startTime = newdrive.startTime;
                     dr.endTime = newdrive.endTime;*/
                    db.SaveChanges();

                    return CONVERTERS.DriverConverter.ConvertDriverToDTo(db.Drivers.FirstOrDefault(d => d.IdDriver == newdrive.IdDriver));
                }
            }
            catch (Exception)
            {

                return Driver;
            }


        }
    }

    /* public static DriverDTO CheckDriver(string email, string password)
     {
         using (finalProjectDBEntities db = new finalProjectDBEntities())
         {
             List<Driver> listdr = db.Drivers.ToList();
             List<DriverDTO> driverDTOdr = new List<DriverDTO>();
             listdr.ForEach(s =>
             {
                 DriverDTO sdto = CONVERTERS.DriverConverter.ConvertDriveToDAL(s);
                 driverDTOdr.Add(sdto);
             });
          DriverDTO myDriver = driverDTOdr.Find(s => s.firstNameDriver == email && s.passwordDriver == password);
             return myDriver;
         }
     }*/





    }


