﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAL;
using System.Data.Entity;

namespace BL
{
    public class InlayBL
    {
        /*public List<InlayDTO> getInlayList()
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
                return CONVERTERS.InlayConverter.ConvertAllInlayToDTo(db.Inlays.ToList());
        }*/

        public static void AddInlayList(List<Inlay> Inlay)
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
                db.Inlays.AddRange(Inlay);
                db.SaveChanges();
            }
        }

        public static List<InlayDTO>  GetInlayList()
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
               return  db.Inlays.Include(i=>i.Kindergarten).Include(i=>i.Driver).ToList().Select(i=>CONVERTERS.InlayConverter.ConvertInlayToDTo(i)).ToList();
                
            }
        }

        public static List<InlayDTO> GetInlayListForDriver(int driverId)
        {
            return GetInlayList().Where(d => d.IdDriver == driverId).OrderBy(i => i.numberKindergarden).ToList();
        }

        internal static void RemoveAll()
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
                db.Inlays.RemoveRange(db.Inlays);
                db.SaveChanges();
            }
            }
    }
}
