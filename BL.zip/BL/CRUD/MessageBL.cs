﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAL;

namespace BL
{
    public class MessageBL
    {
        public static void AddMessage(MessageDTO Message)
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
                db.Messages.Add(CONVERTERS.MessageConverter.ConvertMessageToDAL(Message));
                db.SaveChanges();
            }
        }
    }
}
