﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;

namespace BL
{
    public class SupplyPlaceBL
    {
        //public static void AddSupplyPlace(SupplyPlaceDTO SupplyPlace)
        //{
        //    using (finalProjectDBEntities db = new finalProjectDBEntities())
        //    {
        //        db.SupplyPlaces.Add(CONVERTERS.SupplyPlaceConverter.ConvertSupplyPlaceToDAL(SupplyPlace));
        //        db.SaveChanges();
        //    }
        //}
    }
}
