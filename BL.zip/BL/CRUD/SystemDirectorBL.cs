﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;


namespace BL
{
    public class SystemDirectorBL
    {
        public static List<SystemDirector> GetSystemDirectors()
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
                return CONVERTERS.SystemDirectorConverter.ConvertSystemDirectorToDTo(db.SystemDirectors.ToList());
        }
        /*public static List<SystemDirectorDTO> GetDrivers()
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
                return CONVERTERS.SystemDirectorConverter.ConvertSystemDirectorToDTo(db.SystemDirectors.ToList());
        }*/

        //public static void AddSystemDirector(SystemDirectorDTO SystemDirector)
        //{
        //    using (finalProjectDBEntities db = new finalProjectDBEntities())
        //    {
        //        db.SystemDirectors.Add(CONVERTERS.SystemDirectorConverter.ConvertSystemDirectorToDAL(SystemDirector));
        //        db.SaveChanges();
        //    }
        //}

    }
}
