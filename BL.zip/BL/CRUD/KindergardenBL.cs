﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAL;

namespace BL
{
    public class KindergardenBL
    {
       
        public  List<KindergardensDTO> GetKindergardens()
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
                return CONVERTERS.KindergardenConverter.ConvertAllKindergardensToDTo( db.Kindergartens.ToList());
        }

        public static Kindergarten GetKindergartensOfId(int id)
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
                return db.Kindergartens.Where(w => w.IdKindergarden == id).First();
        }



        public static void AddKindergarden(KindergardensDTO Kindergarden)
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
                db.Kindergartens.Add(CONVERTERS.KindergardenConverter.ConvertKindergardenToDAL(Kindergarden));
                db.SaveChanges();
            }
        }

        public static void DeleteKindergarden(KindergardensDTO kindergarden)
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
                db.Kindergartens.Remove(CONVERTERS.KindergardenConverter.ConvertKindergardenToDAL(kindergarden));
                db.SaveChanges();
            }
        }

        public static KindergardensDTO UpdateKindergartens(KindergardensDTO Kindergartens)
        {
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {

                Kindergarten newKindergartens = CONVERTERS.KindergardenConverter.ConvertKindergardenToDAL(Kindergartens);
                db.Kindergartens.FirstOrDefault(d => d.IdKindergarden == newKindergartens.IdKindergarden).kindergardenName = newKindergartens.kindergardenName;
                db.Kindergartens.FirstOrDefault(d => d.IdKindergarden == newKindergartens.IdKindergarden).KindergartenGroup = newKindergartens.KindergartenGroup;
                db.Kindergartens.FirstOrDefault(d => d.IdKindergarden == newKindergartens.IdKindergarden).addressKindergarden = newKindergartens.addressKindergarden;
                db.Kindergartens.FirstOrDefault(d => d.IdKindergarden == newKindergartens.IdKindergarden).amountFoodInKindergarden = newKindergartens.amountFoodInKindergarden;
                db.Kindergartens.FirstOrDefault(d => d.IdKindergarden == newKindergartens.IdKindergarden).phoneKindergarden = newKindergartens.phoneKindergarden;
                db.Kindergartens.FirstOrDefault(d => d.IdKindergarden == newKindergartens.IdKindergarden).lunchTime = newKindergartens.lunchTime;
                db.SaveChanges();
                return CONVERTERS.KindergardenConverter.ConvertKindergardensToDTo( db.Kindergartens.FirstOrDefault(a=>a.IdKindergarden==Kindergartens.IdKindergarden));
            }

        }
    }
}
