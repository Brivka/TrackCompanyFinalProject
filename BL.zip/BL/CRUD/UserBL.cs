﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XAct.Users;
using DTO;
using BL.CONVERTERS;
namespace BL.CRUD
{
   public class UserBL
    {
     
        public static UserDTO GetUser(string password, string email)
        {
            UserDTO u = new UserDTO();
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
                SystemDirector s = db.SystemDirectors.FirstOrDefault(a => a.passwordSystem.Trim().Equals(password.Trim()) && a.emailSystem.Trim().Equals(email.Trim()));
                if (s != null)
                {
                    u.SystemDirector = CONVERTERS.SystemDirectorConverter.ConvertSystemDirectorToDTo(s);
                    return u;
                }
                Driver d = db.Drivers.FirstOrDefault(a => a.passwordDriver.Trim().Equals(password.Trim()) && a.emailDriver.Trim().Equals(email.Trim()));
                if (d != null)
                {
                    u.Driver = CONVERTERS.DriverConverter.ConvertDriverToDTo(d);
                    return u;
                }
                return null;
            }
        }
    }
}
