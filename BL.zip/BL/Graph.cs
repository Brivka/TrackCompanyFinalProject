﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    public class Graph<T,E>
    {
        private Dictionary<T,E> globalGraph;

        public Dictionary<T, E> GlobalGraph
        {
            get { return globalGraph; }
            set { globalGraph = value; }
        }

        public Graph()
        {
            GlobalGraph = new Dictionary<T, E>();
        }
    }

    public class Graph
    {

        public int globalGraph
        {
            get => default;
            set
            {
            }
        }
    }
}
