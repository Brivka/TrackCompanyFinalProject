﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    public class Route
    {
        static int counter = 0;
        private int idRoute;

        public int IdRoute
        {
            get { return idRoute; }
            set { idRoute = value; }
        }


        private List<Kindergarten> routeKinderGarden;

        public List<Kindergarten> RouteKinderGarden
        {
            get { return routeKinderGarden; }
            set { routeKinderGarden = value; }
        }

       //השעה של תחילת המסלול
        private TimeSpan hourStart;

        public TimeSpan HourStart
        {
            get { return hourStart; }
            set { hourStart = value; }
        }

        //number Dishes of route
        public int TotalBoxes { get; set; }

        //mark of rouet
        public int mark { get; set; }

        public Route()
        {
           idRoute= counter++;
        }
    }
}
