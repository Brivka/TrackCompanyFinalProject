﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL.AlgoritemVRPTW
{
    public class RequestBody
    {


        public Vehicle[] vehicles { get; set; }
        public Service[] services { get; set; }
    }

    public class Vehicle
    {
        public string vehicle_id { get; set; }
        public Address start_address { get; set; }
        public int max_jobs { get; set; }
    }

    //public class Start_Address
    //{
    //    public string location_id { get; set; }
    //    public float lon { get; set; }
    //    public float lat { get; set; }
    //}

    public class Service
    {
        public string id { get; set; }
        public string name { get; set; }
        public Address address { get; set; }
        public Time_Windows[] time_windows { get; set; }
        public int[] size { get; set; }
    }

    public class Address
    {
        public string location_id { get; set; }
        public float lon { get; set; }
        public float lat { get; set; }
    }

    public class Time_Windows
    {
        public long earliest { get; set; }
        public long latest { get; set; }
    }

}

