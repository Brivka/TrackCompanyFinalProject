﻿using DAL;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static BL.AlgoritemVRPTW.RequestBody;

namespace BL.AlgoritemVRPTW
{
    public class RouteOptimization
    {
        List<Driver> drivers;
        List<Kindergarten> Kindergartenss;
        string startAddress;
        public Graph<int,BL.Route> BuildRouts(List<Driver> _drivers, List<Kindergarten> _Kindergartenss, string _startAddress)
        { 
            drivers = _drivers;
            Kindergartenss = _Kindergartenss;
            startAddress = _startAddress;
            Graph<int, BL.Route> graph = new Graph<int, BL.Route>();
            graph.GlobalGraph= GetRoutsFromAPI(CreateRequestBody()).ToDictionary(k => k.IdRoute, v => v);
            return graph;
            

        }

        private RequestBody CreateRequestBody()
        {
            int maxJobs = (Kindergartenss.Count/ drivers.Count);
            RequestBody body = new RequestBody();
            body.vehicles = drivers.Select(d =>
                 new Vehicle {
                     vehicle_id=d.IdDriver.ToString(),
                     max_jobs= maxJobs ,
                     start_address=GetCodedAdress(startAddress)
                 }
            ).ToArray();

            body.services = Kindergartenss.Select(k =>
            new Service {
                id=k.IdKindergarden.ToString(),
                name=k.kindergardenName,
                address=GetCodedAdress(k.addressKindergarden),
                time_windows=new List<Time_Windows>{new Time_Windows {
                    earliest=GetTimeOffset(k.lunchTime.Add(new TimeSpan(-1,0,0))),
                    latest=GetTimeOffset(k.lunchTime)
                    }}.ToArray(),
               

            }).ToArray();

            return body;
        }

        private long GetTimeOffset(TimeSpan lunchTime)
        {
            DateTime time = DateTime.Today+ lunchTime;
            long unixTime = ((DateTimeOffset)time).ToUnixTimeSeconds();
            return unixTime;
        }

        private Address GetCodedAdress(string address)
        {
            string requestUri = string.Format("https://maps.googleapis.com/maps/api/geocode/xml?key={1}&address={0}&sensor=false", Uri.EscapeDataString(address), "https://maps.googleapis.com/maps/api/distancematrix/xml?key=AIzaSyCU-iU2fLRpI3Cs_WvWqKoIF9VTksScEa0&origins=‏");

            WebRequest request = WebRequest.Create(requestUri);
            WebResponse response = request.GetResponse();
            XDocument xdoc = XDocument.Load(response.GetResponseStream());

            XElement result = xdoc.Element("GeocodeResponse").Element("result");
            XElement locationElement = result.Element("geometry").Element("location");
            XElement lat = locationElement.Element("lat");
            XElement lng = locationElement.Element("lng");

            return new Address { lat = float.Parse(lat.Value), lon = float.Parse(lng.Value) };

        }

        private List<BL.Route> GetRoutsFromAPI(RequestBody root)
        {
            var client = new RestClient("https://graphhopper.com/api/1/vrp?key=88b2913c-c03b-4b3c-8a60-927b373d1ab4");
            var request = new RestRequest("",Method.Post);
            request.AddHeader("Content-Type", "application/json");
            var body = root ;
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            RestResponse response = client.Execute(request);
            var res= JsonConvert.DeserializeObject<Result>(response.Content);
            return ConvertResult(res.solution);

        }

        private List<BL.Route> ConvertResult(Solution solution)
        {
            
            int i = 0;
            return solution.routes.Select(r => new BL.Route {
                IdRoute=++i,
                HourStart=DateTime.Parse(r.activities[0].end_date_time.ToString()).TimeOfDay ,
                RouteKinderGarden=r.activities.Select(a=>Kindergartenss.Find(k=>k.IdKindergarden==int.Parse(a.id))).ToList()
            }).ToList();
            
           
        }


    }
}
