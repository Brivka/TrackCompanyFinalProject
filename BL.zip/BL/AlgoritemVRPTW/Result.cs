﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL.AlgoritemVRPTW
{
    public class Result
    {


        public string[] copyrights { get; set; }
        public string job_id { get; set; }
        public string status { get; set; }
        public int waiting_time_in_queue { get; set; }
        public int processing_time { get; set; }
        public Solution solution { get; set; }
    }

    public class Solution
    {
        public int costs { get; set; }
        public int distance { get; set; }
        public int time { get; set; }
        public int transport_time { get; set; }
        public int completion_time { get; set; }
        public int max_operation_time { get; set; }
        public int waiting_time { get; set; }
        public int service_duration { get; set; }
        public int preparation_time { get; set; }
        public int no_vehicles { get; set; }
        public int no_unassigned { get; set; }
        public Route1[] routes { get; set; }
        public Unassigned unassigned { get; set; }
    }

    public class Unassigned
    {
        public string[] services { get; set; }
        public object[] shipments { get; set; }
        public object[] breaks { get; set; }
        public Detail[] details { get; set; }
    }

    public class Detail
    {
        public string id { get; set; }
        public int code { get; set; }
        public string reason { get; set; }
    }

    public class Route1
    {
        public string vehicle_id { get; set; }
        public string shift_id { get; set; }
        public int distance { get; set; }
        public int transport_time { get; set; }
        public int completion_time { get; set; }
        public int waiting_time { get; set; }
        public int service_duration { get; set; }
        public int preparation_time { get; set; }
        public Activity[] activities { get; set; }
    }

    public class Activity
    {
        public string type { get; set; }
        public string location_id { get; set; }
        public Address address { get; set; }
        public int end_time { get; set; }
        public object end_date_time { get; set; }
        public int distance { get; set; }
        public int driving_time { get; set; }
        public int preparation_time { get; set; }
        public int waiting_time { get; set; }
        public int[] load_after { get; set; }
        public string id { get; set; }
        public int arr_time { get; set; }
        public object arr_date_time { get; set; }
        public int[] load_before { get; set; }
    }

   

}

