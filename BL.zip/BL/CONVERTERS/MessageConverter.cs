﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;

namespace BL.CONVERTERS
{
    public class MessageConverter
    {
        public static Message ConvertMessageToDAL(MessageDTO Message)
        {
            return new Message
            {
               IdMessages=Message.IdMessages,
               IdDriver=Message.IdDriver,
               IdSystemDirector=Message.IdSystemDirector,
               dateMessages=Message.dateMessages,
               contentMessages=Message.contentMessages,
               responseMessages=Message.responseMessages,
               statusMessages= Message.statusMessages,
            };
        }
        public static MessageDTO ConvertMessageToDTo(Message Message)
        {
            return new MessageDTO
            {
                IdMessages = Message.IdMessages,
                IdDriver = Message.IdDriver,
                IdSystemDirector = Message.IdSystemDirector,
                dateMessages = Message.dateMessages,
                contentMessages = Message.contentMessages,
                responseMessages = Message.responseMessages,
                statusMessages = Message.statusMessages,
            };
        }
    }
}
