﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;

namespace BL.CONVERTERS
{
    public static class KindergardenConverter
    {
        public static Kindergarten ConvertKindergardenToDAL(KindergardensDTO Kindergartens)
        {
            return new Kindergarten
            {
                IdKindergarden = Kindergartens.IdKindergarden,
                kindergardenName = Kindergartens.kindergardenName,
                KindergartenGroup = Kindergartens.KindergartensGroup,
                addressKindergarden = Kindergartens.addressKindergarden,
                phoneKindergarden = Kindergartens.phoneKindergarden,
                lunchTime = Kindergartens.lunchTime,
                amountFoodInKindergarden = Kindergartens.amountFoodInKindergarden
            };
        }

        public static List<Kindergarten> ConvertAllKindergardenToDAL(List<KindergardensDTO> Kindergartens)
        {
            List<Kindergarten> l = new List<Kindergarten>();
            foreach (KindergardensDTO item in Kindergartens)
            {
                l.Add(ConvertKindergardenToDAL(item));
            }
            return l;
        }
        public static KindergardensDTO ConvertKindergardensToDTo(Kindergarten Kindergartens)
        {
            return new KindergardensDTO
            {
                IdKindergarden = Kindergartens.IdKindergarden,
                kindergardenName = Kindergartens.kindergardenName,
                KindergartensGroup = Kindergartens.KindergartenGroup,
                addressKindergarden = Kindergartens.addressKindergarden,
                phoneKindergarden = Kindergartens.phoneKindergarden,
                lunchTime = Kindergartens.lunchTime,
                amountFoodInKindergarden = Kindergartens.amountFoodInKindergarden
            };
        }
        public static List<KindergardensDTO> ConvertAllKindergardensToDTo(List<Kindergarten> Kindergartens)
        {
            List<KindergardensDTO> l = new List<KindergardensDTO>();
            foreach (Kindergarten item in Kindergartens)
            {
                l.Add(ConvertKindergardensToDTo(item));
            }
            return l;
        }

    }
}
