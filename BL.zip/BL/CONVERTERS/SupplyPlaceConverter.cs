﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAL;

namespace BL.CONVERTERS
{
    public class SupplyPlaceConverter
    {
        public static SupplyPlace ConvertSupplyPlaceToDAL(SupplyPlaceDTO SupplyPlace)
        {
            return new SupplyPlace
            {
                IdSupply = SupplyPlace.IdSupply,
                supplyName = SupplyPlace.supplyName,
                phoneSupply = SupplyPlace.phoneSupply,
                addressSupply = SupplyPlace.addressSupply
            };
        }
        public static SupplyPlaceDTO ConvertSupplyPlaceToDTo(SupplyPlace SupplyPlace)
        {
            return new SupplyPlaceDTO
            {
                IdSupply = SupplyPlace.IdSupply,
                supplyName = SupplyPlace.supplyName,
                phoneSupply = SupplyPlace.phoneSupply,
                addressSupply = SupplyPlace.addressSupply
            };
        }
    }
}
