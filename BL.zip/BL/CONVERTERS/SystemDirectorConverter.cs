﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;

namespace BL.CONVERTERS
{
    public class SystemDirectorConverter
    {
        public static SystemDirector ConvertSystemDirectorToDAL(SystemDirectorDTO SystemDirector)
        {
            return new SystemDirector
            {
                IdSystemDirector=SystemDirector.IdSystemDirector,
                IdSupply=SystemDirector.IdSupply,
                passwordSystem=SystemDirector.passwordSystem,
                trustPasswordSystem=SystemDirector.trustPasswordSystem,
                emailSystem=SystemDirector.emailSystem,
                phoneSystem=SystemDirector.phoneSystem,
            };
        }

        internal static List<SystemDirector> ConvertSystemDirectorToDTo(List<SystemDirector> systemDirectors)
        {
            throw new NotImplementedException();
        }

        public static SystemDirectorDTO ConvertSystemDirectorToDTo(SystemDirector SystemDirector)
    {
        return new SystemDirectorDTO
        {
            IdSystemDirector = SystemDirector.IdSystemDirector,
            IdSupply = SystemDirector.IdSupply,
            passwordSystem = SystemDirector.passwordSystem,
            trustPasswordSystem = SystemDirector.trustPasswordSystem,
            emailSystem = SystemDirector.emailSystem,
            phoneSystem = SystemDirector.phoneSystem,
        };
    }
}
}
