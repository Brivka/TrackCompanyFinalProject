﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAL;

namespace BL.CONVERTERS
{
    public static class InlayConverter
    {
        public static Inlay ConvertInlayToDAL(InlayDTO Inlay)
        {
            return new Inlay
            {
                IdInlay = Inlay.IdInlay,
                IdDriver = Inlay.IdDriver,
                IdKindergarden = Inlay.IdKindergarden,
                numberKindergarden = Inlay.numberKindergarden
            };
        }
        public static InlayDTO ConvertInlayToDTo(Inlay Inlay)
        {
            return new InlayDTO
            {
                IdInlay = Inlay.IdInlay,
                IdDriver = Inlay.IdDriver,
                IdKindergarden = Inlay.IdKindergarden,
                numberKindergarden = Inlay.numberKindergarden,
                kindergardens = CONVERTERS.KindergardenConverter.ConvertKindergardensToDTo(Inlay.Kindergarten),
                NameDriver=Inlay.Driver.firstNameDriver+" "+Inlay.Driver.lastNameDriver
            };
        }
        public static List<InlayDTO> ConvertAllInlayToDTo(List<Inlay> inlay)
        {
            List<InlayDTO> l = new List<InlayDTO>();
            foreach (Inlay item in inlay)
            {
                l.Add(ConvertAllInlayToDTo(item));
            }
            return l;
        }

        private static InlayDTO ConvertAllInlayToDTo(Inlay item)
        {
            throw new NotImplementedException();
        }

        public static List<Inlay> ConvertAllInlayToDAL(List<InlayDTO> inlay)
        {
            List<Inlay> l = new List<Inlay>();
            foreach (InlayDTO item in inlay)
            {
                l.Add(ConvertAllInlayToDAL(item));
            }
            return l;
        }

        private static Inlay ConvertAllInlayToDAL(InlayDTO item)
        {
            throw new NotImplementedException();
        }
    }
}
