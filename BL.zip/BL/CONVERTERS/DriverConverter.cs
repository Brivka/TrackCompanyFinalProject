﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL.CONVERTERS
{
    public static class DriverConverter
    {
        public static Driver ConvertDriveToDAL(DriverDTO driver)
        {
            return new Driver
            {
                IdDriver = driver.IdDriver,
                firstNameDriver = driver.firstNameDriver,
                lastNameDriver = driver.lastNameDriver,
                phoneDriver = driver.phoneDriver,
                emailDriver = driver.emailDriver,
                addressDriver = driver.addressDriver,
                passwordDriver = driver.passwordDriver,
                trustPasswordDriver = driver.trustPasswordDriver,
                containInCar = driver.containInCar,
                startTime=driver.startTime,
                endTime=driver.endTime,

            };
        }

       

        /*public static List<Driver> ConvertAllDriversToDAL(List<DriverDTO> driver)
        {
            List<Driver> l = new List<Driver>();
            foreach (DriverDTO item in driver)
            {
                l.Add(ConvertAllDriversToDAL(item));
            }
            return l;
        }*/

        
        public static List<DriverDTO> ConvertAllDriversToDTo(List<Driver> driver)
        {
            List<DriverDTO> l = new List<DriverDTO>();
            foreach (Driver item in driver)
            {
                l.Add(ConvertDriverToDTo(item));
            }
            return l;
        }


     

        public static DriverDTO ConvertDriverToDTo(Driver driver)
        {
            return new DriverDTO
            {
                IdDriver = driver.IdDriver,
                firstNameDriver = driver.firstNameDriver,
                lastNameDriver = driver.lastNameDriver,
                phoneDriver = driver.phoneDriver,
                emailDriver = driver.emailDriver,
                addressDriver = driver.addressDriver,
                passwordDriver = driver.passwordDriver,
                trustPasswordDriver = driver.trustPasswordDriver,
                containInCar = driver.containInCar,
                startTime=(TimeSpan)driver.startTime,
                endTime=(TimeSpan) driver.endTime
            };
        }


    }
}

        

