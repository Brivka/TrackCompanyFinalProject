﻿using BL;
using DAL;
using FakeItEasy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL.AlgoritemVRPTW;

namespace BL
{
    public class AlgoritemClass
    {
        // רשימות של גנים מאותחלות מ DB
        List<Kindergarten> Kindergartens = new List<Kindergarten>();

        finalProjectDBEntities db = new finalProjectDBEntities();
        public void FillKindergartenssList()
        {
            Kindergartens = db.Kindergartens.ToList();
        }

        public AlgoritemClass()
        {
            RemoveOldInlay();
            FillKindergartenssList();

            //Random
            buildRndRouts();

            //From api
            /* allRouts = new RouteOptimization().BuildRouts(db.Drivers.ToList(), db.Kindergartenss.ToList(), db.SupplyPlaces.FirstOrDefault().addressSupply);
            */
            fullGraph();
            SaveResultToDB();
        }

        //פונקציה שמרוקנת את השיבוץ הישן לפני הפעלת שיבוץ חדש
        private void RemoveOldInlay()
        {
            InlayBL.RemoveAll();
        }

        //פונקצית שמירה של הנתונים בDB
        private void SaveResultToDB()
        {
            List<Inlay> inlaysToSave = new List<Inlay>();
            foreach (var driver in allDriver.GlobalGraph)
            {
                int index = 0;
                foreach (var Kindergartens in driver.Value[0].RouteKinderGarden)
                {
                    inlaysToSave.Add(new Inlay
                    {
                        IdDriver = driver.Key,
                        IdKindergarden = Kindergartens.IdKindergarden,
                        numberKindergarden = ++index
                    });

                }
            }
            InlayBL.AddInlayList(inlaysToSave);
        }

      
        Graph<int, Route> allRouts = new Graph<int, Route>();
        Graph<int, List<Route>> allDriver = new Graph<int, List<Route>>();
        Dictionary<int, int> signalPlacement = new Dictionary<int, int>();
        int maxMark = 5;



        //פונקצית מילוי גרפים
        public void fullGraph()
        {
            List<Driver> ld;
            List<Route> lr;
            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {
                ld = db.Drivers.ToList();
                //עובר על כל הנהגים
                foreach (var item in ld)
                {
                    //הצבה לכל נהג את כל המסלולים=כל הגנים
                    //lr=allRouts.GlobalGraph.Values.Where(x=>x.HourStart)
                    lr = allRouts.GlobalGraph.Values.ToList();
                    //עובר על כל המסלולים
                    foreach (var item2 in lr)
                    {
                        //נותנת ציון למסלול
                        markToRoute(item, item2);
                    }
                    allDriver.GlobalGraph.Add(item.IdDriver, lr);
                }
                schedule();
            }
        }

        public void markToRoute(Driver d, Route r)
        {
            //r.mark = maxMark;
           
            int minuteDiffStart = (int)(r.HourStart - d.startTime).Value.TotalMinutes;

            if (minuteDiffStart < 0 && d.containInCar < 0 && d.containInCar < r.TotalBoxes && r.TotalBoxes < 0)
            {
                r.mark = -1;
                return;
            }
            if (minuteDiffStart == 0 && d.containInCar == r.TotalBoxes)
            {
                r.mark = maxMark;
                return;
            }
            //להוסיף שגם השעה תיהיה הכי קרובה לשעה הנוכחית
            if (d.containInCar > r.TotalBoxes)
            {
                r.mark = maxMark - 1;
                return;
            }
            r.mark = maxMark - (minuteDiffStart / int.Parse(ConfigurationManager.AppSettings["diffMinutes"]));
            /* r.mark = maxMark - (d.containInCar / int.Parse(ConfigurationManager.AppSettings[""]));*/
        }

        public void schedule()
        {
            List<Route> r = new List<Route>();
            int flag = 0;
            for (int i = 1; i < maxMark; i++)
            {
                //עובר על הגרף של כל הנהגים
                foreach (var item in allDriver.GlobalGraph)
                {
                    //שולף את המסלולים עם הציון המסויים
                    r = item.Value.Where(x => x.mark == i).ToList();
                    //עובר על כל המסלולים של הציון המסויים
                    foreach (var item2 in r)
                    {
                        //עובר על הגרף של כל הנהגים
                        foreach (var item3 in allDriver.GlobalGraph)
                        {
                            //עובר על המסלולים של הנהג
                            foreach (var item4 in item3.Value)
                            {
                                //אם המסלול קיים אצל אחד הנהגים עם ציון גבוה יותר אז תסיר את המסלול מאותו נהג
                                if (item4.IdRoute == item2.IdRoute)
                                {
                                    if (item4.mark > item2.mark)
                                    {
                                        //מסיר את המסלול מאותו נהג
                                        item.Value.Remove(item2);
                                        removeSignalRoute(item.Key, item2.IdRoute);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (allDriver.GlobalGraph.Keys.Count > signalPlacement.Count)
            {
                finished();
            }
        }
        //פונקציה שמסירה מסלול בודד
        public void removeSignalRoute(int idDriver, int idRoute)
        {
            int flag = 1;
            List<Route> r;
            Dictionary<int, int> rd = new Dictionary<int, int>();
            while (flag != 0)
            {
                flag = 0;
                if (!signalPlacement.ContainsKey(idDriver))
                {
                    //אם נשאר מסלול בודד אצל אותו נהג
                    r = allDriver.GlobalGraph.FirstOrDefault(x => x.Key == idDriver).Value.ToList();
                    if (r.Count == 1)
                    {
                        removeRouteFromAllDrivers(idDriver, r[0].IdRoute);
                        signalPlacement.Add(idDriver, r[0].IdRoute);
                        idRoute = r[0].IdRoute;
                        flag = 1;
                    }
                }
                else if (flag == 0 && !signalPlacement.ContainsValue(idRoute))
                {
                    //אם המסלול נשאר בודד רק אצל אחד הנהגים
                    foreach (var item in allDriver.GlobalGraph)
                    {
                        if (item.Value.FirstOrDefault(x => x.IdRoute == idRoute) != null)
                        {
                            rd.Add(idRoute, item.Key);
                        }
                    }
                    if (rd.Count == 1)
                    {
                        //אז- תשבץ אותו
                        removeAllRoutesFromDriver(rd.Keys.ElementAt(0), rd.Values.ElementAt(0));
                        signalPlacement.Add(rd.Keys.ElementAt(0), rd.Values.ElementAt(0));
                        idDriver = rd.Keys.ElementAt(0);
                        //idRoute = rd.Values.ElementAt(0);
                        flag = 1;
                    }
                }
            }
        }


        //פונקציה שמקבלת נהג ומסלול ומסירה את שאר המסלולים מאותו נהג
        public void removeAllRoutesFromDriver(int idDriver, int idRoute)

        {
            List<Route> r = allDriver.GlobalGraph.FirstOrDefault(x => x.Key == idDriver).Value;
            r.RemoveAll(x => x.IdRoute != idRoute);
        }



        //פונקציה שמקבלת נהג ומסלול ומסירה את אותו מסלול משאר הנהגים
        public void removeRouteFromAllDrivers(int idDriver, int idRoute)
        {
            foreach (var item in allDriver.GlobalGraph)
            {
                if (item.Key != idDriver)
                {
                    item.Value.RemoveAll(x => x.IdRoute == idRoute);
                }
            }
        }

        public void finished()
        {
            int count = 0;
            Random r = new Random();
            int rand;
            foreach (var item in allDriver.GlobalGraph)
            {
                //שואלת אם יש לנהג יותר ממסלול אחד
                if (item.Value.Count > 1)
                {
                    rand = r.Next(item.Value.Count - 1);
                    int routeId = item.Value.ElementAt(rand).IdRoute;
                    //מסיר מאותו נהג את כל שאר המסולולים
                    removeAllRoutesFromDriver(item.Key, routeId);

                    //מסיר משאר הנהגים את אותו מסלול
                    removeRouteFromAllDrivers(item.Key, routeId);

                    signalPlacement.Add(item.Key, routeId);
                    removeSignalRoute(item.Key, routeId);
                }
            }
        }



        //פונקציה שמאתחלת מסלולים=הגרלת מסלולים
        public void buildRndRouts()
        {
            List<Kindergarten> lk;
            List<Kindergarten> tmplistk;
            int index;
            int count;//סוכם את הנהגים
            int countKinderGarden;//סוכם את הגנים
            int numKindergardenInRoute;//מספר גנים במסלול
            Route route = new Route();
            Random r = new Random();

            using (finalProjectDBEntities db = new finalProjectDBEntities())
            {

                lk = db.Kindergartens.ToList();
                tmplistk = db.Kindergartens.ToList();
                count = db.Drivers.Count();
                countKinderGarden = Kindergartens.Count;
                numKindergardenInRoute = countKinderGarden / count;//מספר גנים לחלק למספר הנהגים
                                                                   //TimeSpan mint = lk.Min(x => x.lunchTime);
                Route route1;

                //עובר על כל  מספר המסלולים
                for (int i = 0; i < count; i++)
                {
                    allRouts.GlobalGraph.Add(i, new Route());
                    allRouts.GlobalGraph.ElementAt(i).Value.RouteKinderGarden = new List<Kindergarten>();
                    //מספר הגנים במסלול
                    // אי זוגי וזוגי 
                    for (int j = 0; j < numKindergardenInRoute || (i == count - 1 && j < tmplistk.Count); j++)
                    {
                        index = r.Next(tmplistk.Count);
                        allRouts.GlobalGraph.ElementAt(i).Value.RouteKinderGarden.Add(tmplistk[index]);
                        allRouts.GlobalGraph.ElementAt(i).Value.TotalBoxes += tmplistk[index].amountFoodInKindergarden;
                        tmplistk.RemoveAt(index);
                    }
                }
                for (int j = 0; j < count; j++)
                {
                    // HourStart=השעה של תחילת המסלול=lunchTime-1
                    allRouts.GlobalGraph.ElementAt(j).Value.RouteKinderGarden =
                    allRouts.GlobalGraph.ElementAt(j).Value.RouteKinderGarden.OrderBy(x => x.lunchTime).ToList();
                    allRouts.GlobalGraph.ElementAt(j).Value.HourStart = allRouts.GlobalGraph.ElementAt(j).Value.RouteKinderGarden[0].lunchTime;
                    allRouts.GlobalGraph.ElementAt(j).Value.HourStart += TimeSpan.FromHours(-1);
                }
            }
        }
    }

}



