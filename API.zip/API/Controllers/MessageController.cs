﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using DTO;

namespace API.Controllers
{
    [EnableCors("*", "*", "*")]
    [RoutePrefix("api/Massage")]

    public class MessageController : ApiController
    {

        //
        [Route("GetNumMessage")]
        [HttpGet]
        public IHttpActionResult GetNumMessage()
        {
            return Ok(6);
        }


        [Route("AddMessage"), HttpPost]
        public IHttpActionResult AddMessage(MessageDTO Message)
        {
            BL.MessageBL.AddMessage(Message);
            return Ok(true);
        }
    }
}
