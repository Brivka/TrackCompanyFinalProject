﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using BL;
using BL.CRUD;
using DTO;

namespace API.Controllers
{
    [EnableCors("*","*","*")]
    [RoutePrefix("api/User")]

    public class UserController : ApiController
    {
        //למחוק

        [Route("IsSystemDriver")]
        [HttpGet]
        public UserDTO IsSystemDriver(string password, string email)
        {
            return UserBL.GetUser(password, email);
        }
    }
}
