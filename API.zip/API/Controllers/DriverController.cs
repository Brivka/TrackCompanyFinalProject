﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DTO;
using System.Web.Http.Cors;
using BL;


namespace API.Controllers
{
    [EnableCors("*", "*", "*")]
    [RoutePrefix("api/Driver")]

    public class DriverController : ApiController
    {
        DriverBL driverBL = new DriverBL();
        [Route("GetDrivers")]
        [HttpGet]


        public IHttpActionResult GetDrivers()
        {
            
            List<DriverDTO> l = DriverBL.GetDrivers();
          return Ok (DriverBL.GetDrivers());
             
        }
        [Route("GetDriveOfId"), HttpGet]
        public IHttpActionResult GetDriveOfId(int id)
        {
            // GetDriveOfId(id);
            return Ok(true);
        }

        [Route("Getdrivers"), HttpPost]
        public IHttpActionResult Getdrivers(string email, string password)
        {
            return Ok(DriverBL.Getdrivers(email, password));
        }

        [Route("AddDriver"), HttpPost]
        public bool AddDriver(DriverDTO driver)
        {
          return   BL.DriverBL.AddDriver(driver);
        }

        [Route("DeleteDriver"), HttpPost]
        public IHttpActionResult DeleteDriver(DriverDTO Driver)
        {
            BL.DriverBL.DeleteDriver(Driver);
            return Ok(true);
        }

        [Route("UpdateDrive"), HttpPost]
        public DriverDTO UpdateDrive(DriverDTO driver)
        {
            return DriverBL.UpdateDrive(driver);
        }
/*
        [Route("CheckDriver"), HttpPost]
        public IHttpActionResult CheckDriver(string email,string password)
        {
            BL.DriverBL.CheckDriver(email,password);
            return Ok(true);
        }*/



       /* DriverDTO u = new DriverDTO();


        [Route("/IsSystemDriver")]
        public IHttpActionResult IsSystemDriver(string password, string email)
        {
            //userName,password
            //BL.UserBL.IsSystemDriver(userName,password);
            //return Os(User)
            return GetDrivers();
        }*/
    }
}
