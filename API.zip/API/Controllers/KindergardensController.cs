﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using DTO;
using BL;

namespace API.Controllers
{
    [EnableCors("*","*","*")]
    [RoutePrefix("api/Kindergardens")]

    public class KindergardensController : ApiController
    {
        KindergardenBL kindergardenBL = new KindergardenBL();
        [Route("GetKindergardens")]
        [HttpGet]
        public List<KindergardensDTO> GetKindergardens()
        {
          return kindergardenBL.GetKindergardens();
        }

        [Route("GetKindergartensOfId"), HttpGet]
        public IHttpActionResult GetKindergartensOfId(int id)
        {
            // GetKindergartensOfId(id);
            return Ok(true);
        }

       
        [Route("AddKindergarden"), HttpPost]
        public IHttpActionResult AddKindergarden([FromBody] KindergardensDTO kindergarden)
        {
            BL.KindergardenBL.AddKindergarden(kindergarden);
            return Ok(true);
        }

        [Route("DeleteKindergarden"), HttpPost]
        public IHttpActionResult DeleteKindergarden(KindergardensDTO kindergarden)
        {
            BL.KindergardenBL.DeleteKindergarden(kindergarden);
            return Ok(true);
        }

        [Route("UpdateKinderGarden"), HttpPost]
        public KindergardensDTO UpdateKindergartens(KindergardensDTO kindergarden)
        {

          return  BL.KindergardenBL.UpdateKindergartens(kindergarden);
        }

    }
}
