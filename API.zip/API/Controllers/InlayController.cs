﻿using BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using DTO;

namespace API.Controllers
{
    [EnableCors("*", "*", "*")]
    [RoutePrefix("api/Inlay")]

    public class InlayController : ApiController
    {

        // פונקציה שמבצעת את האלגוריתם מהתחלה . כלומר, עם שינויים אפשר לראות את האלגוריתם עם נקודות עצירה
        [HttpGet,Route("get")]
        public IHttpActionResult Get()
        {
            var schedule = new AlgoritemClass();
            return Ok();
        }

        //פונקציה שמחזירה את הרשימה של האלגוריתם גם עם שינויים 
        [HttpGet, Route("getInlayList")]
        public IHttpActionResult GetInlayList()
        {
            Get();
            return Ok(InlayBL.GetInlayList());
        }

        // פונקציה שמחזירה את הרשימה של האלגוריתם גם עם שינויים לפי הזהות של הנהג
        [HttpGet, Route("GetInlayListForDriver")]
        public List<InlayDTO> GetInlayListForDriver([FromUri] int id)
        {
            List < InlayDTO > l=InlayBL.GetInlayListForDriver(id);
            return l;
        }






        /*

        InlayBL kindergardenBL = new InlayBL();
        [Route("GetInlay")]
        [HttpGet]
        public List<InlayDTO> GetInlay()
        {
            return InlayBL.GetInlay();
        }*/
    }
}
