import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { AddKindergardensComponent } from './components/add-kindergardens/add-kindergardens.component';
import { AddDriverComponent } from './components/add-driver/add-driver.component';
import { UserService } from './shared/services/user.service';
import { KindergardensComponent } from './components/kindergardens/kindergardens.component';
import { DriverDetailsComponent } from './components/driver-details/driver-details.component';
import { KindergardenUpdateComponent } from './components/kindergarden-update/kindergarden-update.component';
import { DriverInlayComponent } from './components/driver-inlay/driver-inlay.component';
import { SystemInlayComponent } from './components/system-inlay/system-inlay.component';
import { MessageComponent } from './components/message/message.component';
import { DriversComponent } from './components/drivers/drivers.component';
import{LoginComponent} from './components/login/login.component'
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdateDriverService } from './shared/services/update-driver.service';
import { UpdatekindergatrdenService } from './shared/services/updatekindergatrden.service';
import { DriverUpdateComponent } from './components/drivers-update/drivers-update.component';

@NgModule({
  declarations: [
    AppComponent,
    AddKindergardensComponent,
    AddDriverComponent,
   LoginComponent,
    KindergardensComponent,
    DriverDetailsComponent,
    KindergardenUpdateComponent,
    DriverInlayComponent,
    SystemInlayComponent,
    MessageComponent,
    DriversComponent,
  DriversComponent,
  DriverUpdateComponent,
  KindergardenUpdateComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,  
      
  ],
  providers: [UserService, UpdateDriverService,UpdatekindergatrdenService],
  bootstrap: [AppComponent]
})
export class AppModule { 


}
