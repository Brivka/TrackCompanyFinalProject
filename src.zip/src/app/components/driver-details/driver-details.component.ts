
import { Driver } from 'src/app/shared/models/Driver.model';
import { DriverDetailsService } from 'src/app/shared/services/driver-details.service';
import { DriverService } from 'src/app/shared/services/driver.service';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UserService } from 'src/app/shared/services/user.service';


@Component({
  selector: 'app-driver-details',
  templateUrl: './driver-details.component.html',
  styleUrls: ['./driver-details.component.css']
})
export class DriverDetailsComponent implements OnInit {
  
    constructor( private driverdetailsService: DriverDetailsService,private driverService:DriverService,private UserService:UserService) {
      this.driver = this.UserService.driver;
    }
    driver: Driver;
    DetailsUpdateDriver:Array<Driver>=[];

  ngOnInit(): void {
  }

  submiteUpdateDetaile(driver:Driver){
    this.driverService.UpdateDrive(this.driver).subscribe(
      (    res:boolean)=>{
        console.log(res)
      }
    )
  }


}
