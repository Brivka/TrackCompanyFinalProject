import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddKindergardensComponent } from './add-kindergardens.component';

describe('AddKindergardensComponent', () => {
  let component: AddKindergardensComponent;
  let fixture: ComponentFixture<AddKindergardensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddKindergardensComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddKindergardensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
