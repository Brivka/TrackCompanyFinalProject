import { Component, OnInit } from '@angular/core';
import { subscribeOn } from 'rxjs';
import { Kindergardens } from 'src/app/shared/models/kindergardens.model';
import { KindergardensService } from 'src/app/shared/services/kindergardens.service';
//לעשות אפשרות של מחיקת נהג ע"י זה שכל השדות יהיו ריקות ואז לוחץ על עדכןוהנהג נמחק כלומר,
//אם כל השדות ריקות -תמחק את הנהג
@Component({
  selector: 'app-add-kindergardens',
  templateUrl: './add-kindergardens.component.html',
  styleUrls: ['./add-kindergardens.component.css']
})
export class AddKindergardensComponent implements OnInit {
  kindergarden:Kindergardens =new Kindergardens();
  constructor(private kindergardenService:KindergardensService) 
  {
    
  }

  ngOnInit(): void {
    // this.kindergarden.IdKindergarden=1;
    // this.kindergarden.kindergardenName="גן הוורד";
    // this.kindergarden.KindergartenGroup="גני נווה";
    // this.kindergarden.addressKindergarden="הרב צבאן 100";
    // this.kindergarden.phoneKindergarden="089933473";
    // this.kindergarden.lunchTime="13:00";
    // this.kindergarden.amountFoodInKindergarden=30;
    // this.addKindergardens();
    // this.kindergardenService.getNumkindergardens().subscribe(
    //   res=> {console.log('num kindergardens'+res)},
    //  err=>{console.error(err)}
    // )

  }

  // addKindergardens(){
  //  this.kindergardenService.addkindergardens(this.kindergarden).subscribe(
  //    res=> {console.log(res)},
  //    err=>{console.error(err)}
  //  )
  // }
  addKinder(){
    console.log(this.kindergarden);
    
this.kindergardenService.addkindergardens(this.kindergarden).subscribe(res=>{
  console.log(res);
  
})
  }
}
