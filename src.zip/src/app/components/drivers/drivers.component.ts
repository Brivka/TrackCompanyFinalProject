import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Driver } from 'src/app/shared/models/Driver.model';
import { DriverService } from 'src/app/shared/services/driver.service';
import { UpdateDriverService } from 'src/app/shared/services/update-driver.service';

@Component({
  selector: 'app-drivers',
  templateUrl: './drivers.component.html',
  styleUrls: ['./drivers.component.css']
})
export class DriversComponent implements OnInit {
  AllDrivers: Array<Driver>=new Array<Driver>();
  constructor(private driverSer:DriverService, private router:Router,private updateDriverService:UpdateDriverService) {
driverSer.GetAllDrivers().subscribe(res=>{ 
this.AllDrivers=res;
console.log(res);

})
}

  ngOnInit(): void {
    
  }

  add(){
    this.router.navigate(['/add-driver'])
  }

  update(driver:Driver){
    this.updateDriverService.driverToUpdate=driver;
    this.router.navigate(['/drivers_update'])
  }
}
