import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SystemDirector } from 'src/app/shared/models/SystemDirector.model';
import { UserService } from 'src/app/shared/services/user.service';
import { user } from '../../shared/models/User';
import { DriverService } from '../../shared/services/driver.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   
   constructor(private driveService:DriverService,private userService:UserService,
    private router:Router) { }
  
   signInForm: FormGroup | any;
   signInError: boolean = false
    user: user | any;
 
    ngOnInit(): void {
   this.signInForm= new FormGroup({
     email: new FormControl('', Validators.compose([Validators.required, Validators.maxLength(20),
     Validators.pattern("@"),Validators.pattern("."), Validators.minLength(6)])),
      password: new FormControl('', Validators.compose([Validators.required, Validators.maxLength(12),
     Validators.pattern("^[a-z ]*$"), Validators.minLength(2)])),
    })
    }

//פונקציה שבודקת אם זה נהג או מנהל
  IsSystemDriver(pass: string, email: string) {
    this.userService.IsSystemDriver(pass,email).subscribe (res=>{
           if(res?.Driver!=null) {
            console.log(res.Driver);
            
        this.userService.setCurrentDriver(res.Driver)
        this.router.navigate(['/driver-inlay']);
      }

        else if(res?.SystemDirector!=null)
      
            this.router.navigate(['/system-inlay']);
            else this.signInError=true;
    
         
  },
  

)






// export class SignInComponent implements OnInit {
//   //1.add service to component
//    constructor(  private userService:UserService) { }
  
//    signInForm: FormGroup | any;
//    signInError: boolean = false
//    user: User | any;
 
//    ngOnInit(): void {
//    this.signInForm= new FormGroup({
//      email: new FormControl('', Validators.compose([Validators.required, Validators.maxLength(15),
//      Validators.pattern("@"),Validators.pattern("."), Validators.minLength(2)])),
//      password: new FormControl('', Validators.compose([Validators.required, Validators.maxLength(15),
//      Validators.pattern("^[a-z ]*$"), Validators.minLength(2)])),
//    })
//    }
 
//    //3. creat function
//    checkUser(pass:string,username:string){
//      //4.use the service
//      this.userService.checkUser(pass,username).subscribe(res=>{
//        console.log(res)
//        if(res==true){}
//      } )
//    }
//  }
} 
}
