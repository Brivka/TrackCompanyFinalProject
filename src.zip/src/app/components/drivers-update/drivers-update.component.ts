import { Driver } from 'src/app/shared/models/Driver.model';
import { DriverService } from 'src/app/shared/services/driver.service';
import { UpdateDriverService } from 'src/app/shared/services/update-driver.service';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-drivers-update',
  templateUrl: './drivers-update.component.html',
  styleUrls: ['./drivers-update.component.css']
})
export class DriverUpdateComponent implements OnInit {
  constructor(private updateDriverService: UpdateDriverService,private driverService:DriverService) {
    this.driver = this.updateDriverService.driverToUpdate;
  }
  driver: Driver;
  Updateriver:Array<Driver>=[];
  choose="בחר כלי רכב"
ngOnInit():void{

}
 
  updatesubmit(){
    if(this.driver.passwordDriver!.trim()==this.driver.trustPasswordDriver!.trim()&&this.driver.emailDriver?.includes('@'))
    {
      console.log(this.choose);
    this.driverService.UpdateDrive(this.driver).subscribe(
      (    res:boolean)=>{
        if(this.choose=="canada"){
          console.log("000");
          this.driver.containInCar=50
          
        }
        else if(this.choose=="usa")
        {
          console.log("111");
        this.driver.containInCar=100
        }
        else{
          console.log("222");
        this.driver.containInCar=200
        }

        console.log(res)
      }
     ) }
    
  }
}

