import { Component, OnInit } from '@angular/core';
import { Driver } from 'src/app/shared/models/Driver.model';
import { AddDriverService } from 'src/app/shared/services/add-driver.service';
import { DriverService } from 'src/app/shared/services/driver.service';

@Component({
  selector: 'app-add-driver',
  templateUrl: './add-driver.component.html',
  styleUrls: ['./add-driver.component.css']
})
export class AddDriverComponent implements OnInit {

 

  constructor(private driverService:DriverService,private addDriverService:AddDriverService) {
   
   }
   choose="בחר כלי רכב"
   driver: Driver = new Driver;
   AddDriver:Array<Driver>=[];
  ngOnInit(): void {

  }
  adddriver(){
    if(this.driver.passwordDriver!.trim()==this.driver.trustPasswordDriver!.trim()&&this.driver.emailDriver?.includes('@'))
    {
    console.log(this.choose);
    
    this.driverService.addDrive(this.driver).subscribe(
      (   res:boolean)=>{
        if(this.choose=="canada"){
          console.log("000");
          this.driver.containInCar=50
          
        }
        else if(this.choose=="usa")
        {
          console.log("111");
        this.driver.containInCar=100
        }
        else{
          console.log("222");
        this.driver.containInCar=200
        }

        console.log(res)
      }
    )
   
  }}
  // update(){
  //   this.route.navigation(['driver-update'])

  // }
//   but(){
// this.route.navigation([''])
//   }
}
