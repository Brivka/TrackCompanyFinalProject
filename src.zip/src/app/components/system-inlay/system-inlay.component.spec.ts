import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemInlayComponent } from './system-inlay.component';

describe('SystemInlayComponent', () => {
  let component: SystemInlayComponent;
  let fixture: ComponentFixture<SystemInlayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SystemInlayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemInlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
