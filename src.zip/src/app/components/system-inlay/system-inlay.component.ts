import { Component, OnInit } from '@angular/core';
import { Inlay } from 'src/app/shared/models/Inlay.model';
import { InlayService } from 'src/app/shared/services/inlay.service';

@Component({
  selector: 'app-system-inlay',
  templateUrl: './system-inlay.component.html',
  styleUrls: ['./system-inlay.component.css']
})
export class SystemInlayComponent implements OnInit {
  AllInlay: Array<Inlay>=new Array<Inlay>();
 
  constructor(private InlaySer:InlayService) {

    
InlaySer.GetAllInlay().subscribe(res=>{ 
this.AllInlay=res;
})
  }
  ngOnInit(): void {
  }
  reset(){
    this.InlaySer.GetAllInlay().subscribe(res=>{ 
      this.AllInlay=res;
      })}
  }
