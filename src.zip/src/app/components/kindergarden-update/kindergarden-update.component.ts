import { Component, OnInit } from '@angular/core';
import { Kindergardens } from 'src/app/shared/models/kindergardens.model';
import { KindergardensService } from 'src/app/shared/services/kindergardens.service';
import { UpdatekindergatrdenService } from 'src/app/shared/services/updatekindergatrden.service';

@Component({
  selector: 'app-kindergarden-update',
  templateUrl: './kindergarden-update.component.html',
  styleUrls: ['./kindergarden-update.component.css']
})
export class KindergardenUpdateComponent implements OnInit {

  constructor(private updateKindergardenService:UpdatekindergatrdenService,private kindergardenService:KindergardensService) {
    this.kindergarden=this.kindergardenService.currentKinder;
   }

  kindergarden:Kindergardens;
  UpdateKindergarden:Array<Kindergardens>=[];
 

ngOnInit():void{

}
update(){
this.kindergardenService.UpdateKindergarden(this.kindergarden).subscribe(res=>{
  console.log(res);
  
})
}
  
}
