import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KindergardenUpdateComponent } from './kindergarden-update.component';

describe('KindergardenUpdateComponent', () => {
  let component: KindergardenUpdateComponent;
  let fixture: ComponentFixture<KindergardenUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KindergardenUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KindergardenUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
