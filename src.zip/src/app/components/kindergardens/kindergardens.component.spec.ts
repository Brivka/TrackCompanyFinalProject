import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KindergardensComponent } from './kindergardens.component';

describe('KindergardensComponent', () => {
  let component: KindergardensComponent;
  let fixture: ComponentFixture<KindergardensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KindergardensComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KindergardensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
