import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Kindergardens } from 'src/app/shared/models/kindergardens.model';
import { KindergardensService } from 'src/app/shared/services/kindergardens.service';
import { UpdatekindergatrdenService } from 'src/app/shared/services/updatekindergatrden.service';

@Component({
  selector: 'app-kindergardens',
  templateUrl: './kindergardens.component.html',
  styleUrls: ['./kindergardens.component.css']
})
export class KindergardensComponent implements OnInit {
  AllKinderGarden: Array<Kindergardens>=new Array<Kindergardens>();

  constructor(private KinderGartenSer:KindergardensService,private router:Router,updatekindergardenService:UpdatekindergatrdenService) {
KinderGartenSer.GetAllKindergarten().subscribe(res=>{ 
this.AllKinderGarden=res;
})
   }

  ngOnInit(): void {
  }
 
  addKinderGar(){
    this.router.navigate(['/add-kindergardens'])
  }
  updateKindergarden(kindergarden:Kindergardens){
    this.KinderGartenSer.currentKinder=kindergarden
    this.router.navigate(['/kindergarden-update'])
  }

}
