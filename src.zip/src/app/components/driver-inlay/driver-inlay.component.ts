import { Component, OnInit } from '@angular/core';
import { Inlay } from 'src/app/shared/models/Inlay.model';
import { DriverInlayService } from 'src/app/shared/services/driver-inlay.service';
import { InlayService } from 'src/app/shared/services/inlay.service';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-driver-inlay',
  templateUrl: './driver-inlay.component.html',
  styleUrls: ['./driver-inlay.component.css']
})
export class DriverInlayComponent implements OnInit {
  InlayOfID: Array<Inlay> = new Array<Inlay>();
  constructor(private InlayIDSer: DriverInlayService, private InlaySer: InlayService, private UserService: UserService) {
    InlaySer.GetInlayListForDriver(UserService.driver.IdDriver).subscribe(res => {
    //  console.log(res + "0");
      console.log(res[0].kindergardens);
      this.InlayOfID = res;
      console.log(this.InlayOfID);
      console.log(this.InlayOfID[0].kindergardens.kindergardenName);
      

    })
  }
  ngOnInit(): void {

  }

}
