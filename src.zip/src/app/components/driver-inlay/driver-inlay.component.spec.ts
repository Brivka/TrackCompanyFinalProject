import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverInlayComponent } from './driver-inlay.component';

describe('DriverInlayComponent', () => {
  let component: DriverInlayComponent;
  let fixture: ComponentFixture<DriverInlayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DriverInlayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverInlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
