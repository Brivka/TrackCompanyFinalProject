import { TestBed } from '@angular/core/testing';

import { KindergardensService } from './kindergardens.service';

describe('KindergardensService', () => {
  let service: KindergardensService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KindergardensService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
