import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Driver } from '../models/Driver.model';
import { UpdateDriverService } from './update-driver.service';

@Injectable({
  providedIn: 'root'
})

export class DriverService {
  driver: Driver = new Driver()


  setCurrentDriver(dirver: any) {
    this.driver = dirver
  }

  constructor(private http: HttpClient) { }

  addDrive(driver: Driver): Observable<boolean> {
    return this.http.post<boolean>(environment.url + 'Driver/AddDriver', driver)
  }

  getNumkindergardens(): Observable<number> {
    return this.http.get<number>(environment.url + 'Driver/GetNumDriver')
  }
  GetAllDrivers() {
    return this.http.get<Array<Driver>>(environment.url + 'Driver/GetDrivers')
  }
  UpdateDrive(driver: Driver): Observable<boolean> {
    return this.http.post<boolean>(environment.url + 'Driver/UpdateDrive', driver)
  }
  GetDriveOfId(driver: Driver) {
    return this.http.get<Array<Driver>>(environment.url + 'Driver/GetDriveOfId')
  }
}