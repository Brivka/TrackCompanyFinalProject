
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Driver } from '../models/Driver.model';
import { SystemDirector } from '../models/SystemDirector.model';
import { user } from '../models/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  driver:Driver=new Driver()
  systemDirector:SystemDirector=new SystemDirector()
  setCurrentDriver(Driver: Driver) {
  this.driver=Driver
  console.log(this.driver);
  
  }
 

  constructor(private http: HttpClient) {
  }
  IsSystemDriver(password:string, email:string){


   
    return this.http.get<user>(environment.url + `User/IsSystemDriver?password=${password}&email=${email}`);
  }

}


