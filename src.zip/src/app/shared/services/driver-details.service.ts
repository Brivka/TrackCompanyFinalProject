import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Driver } from '../models/Driver.model';
import { DriverService } from './driver.service';

@Injectable({
  providedIn: 'root'
})
export class DriverDetailsService {
  driverDetailsToUpdate:Driver=new Driver
  constructor(private driverService:DriverService,private http:HttpClient) { }

  GetDriveOfId(driver: Driver) {
    return this.http.get<Array<Driver>>(environment.url + 'Driver/GetDriveOfId')
  }
}
