import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Inlay } from '../models/Inlay.model';
import { InlayService } from './inlay.service';

@Injectable({
  providedIn: 'root'
})
export class SystemInlayService {

  constructor(private http:HttpClient,private inlayService:InlayService) { }
  
  GetAllInlay(){
    return this.http.get<Array<Inlay>>(environment.url+'Inlay/getInlayList')
  }
}
