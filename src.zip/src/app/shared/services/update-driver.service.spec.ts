import { TestBed } from '@angular/core/testing';

import { UpdateDriverService } from './update-driver.service';

describe('UpdateDriverService', () => {
  let service: UpdateDriverService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpdateDriverService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
