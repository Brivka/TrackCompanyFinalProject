import { TestBed } from '@angular/core/testing';

import { InlayService } from './inlay.service';

describe('InlayService', () => {
  let service: InlayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InlayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
