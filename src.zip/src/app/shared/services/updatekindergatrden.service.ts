import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Kindergardens } from '../models/kindergardens.model';
import { KindergardensService } from './kindergardens.service';

@Injectable({
  providedIn: 'root'
})
export class UpdatekindergatrdenService {
  kindergardenToUpdate:Kindergardens=new Kindergardens
  constructor(private http:HttpClient,private kindergardenService:KindergardensService) {
   
   }
   
  UpdateKindergarden(kinderGarden:Kindergardens):Observable<boolean>
{
  return this.http.post<boolean>(environment.url+'kindergarden/UpdateKindergarden',kinderGarden)
}
 

}
