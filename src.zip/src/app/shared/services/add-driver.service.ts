import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Driver } from '../models/Driver.model';

@Injectable({
  providedIn: 'root'
})
export class AddDriverService {
  driveService: any;
  // UpdateDriver(Driver: Driver) {
  //  this.driveService.UpdateDrive(Driver)
  // }

  // driverToUpdate:Driver=new Driver

  constructor(private http:HttpClient) { }

  addDrive(driver:Driver):Observable<boolean>
{
  return this.http.post<boolean>(environment.url+'Driver/AddDriver',driver)
}
}
