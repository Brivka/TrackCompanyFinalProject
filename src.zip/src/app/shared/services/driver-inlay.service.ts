import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Inlay } from '../models/Inlay.model';
import { InlayService } from './inlay.service';

@Injectable({
  providedIn: 'root'
})
export class DriverInlayService {

  constructor(private http :HttpClient,private inlayService:InlayService) { }
  
GetInlayOfID()
{
  return this.http.get<Array<Inlay>>(environment.url+'Inlay/getInlayList/{id}')
}
GetInlayListForDriver(){
  return this.http.get<Array<Inlay>>(environment.url+'Inlay/GetInlayListForDriver{id}')
}
}
