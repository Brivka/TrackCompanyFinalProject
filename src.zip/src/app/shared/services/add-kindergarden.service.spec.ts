import { TestBed } from '@angular/core/testing';

import { AddKindergardenService } from './add-kindergarden.service';

describe('AddKindergardenService', () => {
  let service: AddKindergardenService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddKindergardenService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
