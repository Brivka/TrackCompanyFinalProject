import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Inlay } from '../models/Inlay.model';

@Injectable({
  providedIn: 'root'
})
export class InlayService {
  router: any;

  constructor(private http:HttpClient) { }


GetAllInlay()
{
  return this.http.get<Array<Inlay>>(environment.url+'Inlay/GetInlayList')
}
GetInlayListForDriver(id:number){
  return this.http.get<Array<Inlay>>(environment.url+`Inlay/GetInlayListForDriver?id=${id}`)
}

Get(){
  return this.http.get<Array<Inlay>>(environment.url+'Inlay/get')
}
}
