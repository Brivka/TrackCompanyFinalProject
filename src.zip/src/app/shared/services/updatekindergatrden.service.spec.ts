import { TestBed } from '@angular/core/testing';

import { UpdatekindergatrdenService } from './updatekindergatrden.service';

describe('UpdatekindergatrdenService', () => {
  let service: UpdatekindergatrdenService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpdatekindergatrdenService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
