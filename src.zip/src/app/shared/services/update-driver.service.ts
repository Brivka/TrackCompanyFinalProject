import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Driver } from '../models/Driver.model';
import { DriverService } from './driver.service';

@Injectable({
  providedIn: 'root'
})
export class UpdateDriverService {
 
  // UpdateDriver(Driver: Driver) {
  //  this.driveService.UpdateDrive(Driver)
  // }

  driverToUpdate:Driver=new Driver
  constructor(private http:HttpClient,private driveService:DriverService) {
   
   }
   
   UpdateDrive(driver:Driver):Observable<boolean>
{
  return this.http.post<boolean>(environment.url+'driver/UpdateDrive',driver)
}
 
}
