import { TestBed } from '@angular/core/testing';

import { SystemInlayService } from './system-inlay.service';

describe('SystemInlayService', () => {
  let service: SystemInlayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SystemInlayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
