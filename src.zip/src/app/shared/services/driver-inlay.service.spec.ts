import { TestBed } from '@angular/core/testing';

import { DriverInlayService } from './driver-inlay.service';

describe('DriverInlayService', () => {
  let service: DriverInlayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DriverInlayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
