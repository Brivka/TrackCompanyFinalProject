import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Kindergardens } from '../models/kindergardens.model';

import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class KindergardensService {
  currentKinder:Kindergardens=new Kindergardens()

  constructor(private http:HttpClient) { }

  UpdateKindergarden(kindergarden: Kindergardens) {
    return this.http.post<boolean>(environment.url+'Kindergardens/UpdateKinderGarden',kindergarden)
  }
  addkindergardens(kindergarden:Kindergardens) :Observable<boolean>
  {
   return this.http.post<boolean>(environment.url+'Kindergardens/AddKindergarden',kindergarden)
  }

  getNumkindergarden():Observable<number>
  {
    return this.http.get<number>(environment.url+'GetNumKindergardens')
  }
  GetAllKindergarten()
  {
    return this.http.get<Array<Kindergardens>>(environment.url+'Kindergardens/GetKindergardens')
  }

}
