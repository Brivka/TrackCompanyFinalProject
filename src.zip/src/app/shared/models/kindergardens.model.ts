import { Time } from "@angular/common"
import { Router } from "@angular/router"

export class Kindergardens{
    IdKindergarden:number | undefined
    kindergardenName:string | undefined
    KindergartensGroup:string | undefined
    addressKindergarden:string | undefined
    phoneKindergarden:string | undefined
    lunchTime:string | undefined
    amountFoodInKindergarden:number | undefined
}