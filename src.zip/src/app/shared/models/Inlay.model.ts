import { Time } from "@angular/common"
import { Router } from "@angular/router"
import { Driver } from "./Driver.model"
import { Kindergardens } from "./kindergardens.model"

export class Inlay{
    IdInlay:number | undefined
    IdDriver:string | undefined
     NameDriver :string|undefined

    IdKindergarden:string | undefined
    numberKindergarden:number | undefined
         
    kindergardens:Kindergardens=new Kindergardens()

   
  //  driver:Driver=new Driver()
}