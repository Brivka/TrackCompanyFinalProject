import { Time } from "@angular/common"
import { Router } from "@angular/router"

export class SupplyPlace{
    IdSupply:number | undefined
    supplyName:string | undefined
    phoneSupply:string | undefined
    addressSupply:string | undefined
}