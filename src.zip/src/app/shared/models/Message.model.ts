import { Time } from "@angular/common"
import { Router } from "@angular/router"

export class Message{
    IdMessages:number | undefined
    IdDriver:number | undefined
    IdSystemDirector:number | undefined
    dateMessages:Date | undefined
    contentMessages:string | undefined
    responseMessages:string | undefined
    statusMessages:boolean | undefined
}