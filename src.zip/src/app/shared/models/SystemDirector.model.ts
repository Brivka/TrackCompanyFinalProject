import { Time } from "@angular/common"
import { Router } from "@angular/router"

export class SystemDirector{
    IdSystemDirector:number | undefined
    IdSupply:number | undefined
    passwordSystem:string | undefined
    trustPasswordSystem:string | undefined
    emailSystem:string | undefined
    phoneSystem:string | undefined
}