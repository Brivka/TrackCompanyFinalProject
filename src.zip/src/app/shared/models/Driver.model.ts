import { Time } from "@angular/common"
import { Router } from "@angular/router"

export class Driver{
    IdDriver:number = 0
    firstNameDriver?:string 
    lastNameDriver!:string 
    phoneDriver:string | undefined
    emailDriver:string | undefined
    addressDriver:string | undefined
    passwordDriver:string | undefined
    trustPasswordDriver:string | undefined
    containInCar:number | undefined
    startTime:Time | undefined
    endTime:Time | undefined
}