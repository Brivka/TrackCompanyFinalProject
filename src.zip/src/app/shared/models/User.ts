import { Driver } from "./Driver.model";
import { SystemDirector } from "./SystemDirector.model";

export class user{

    constructor(
        public Driver:Driver,
        public SystemDirector:SystemDirector)
    {  }
}