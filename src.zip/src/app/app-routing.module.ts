import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddDriverComponent } from './components/add-driver/add-driver.component';
import { AddKindergardensComponent } from './components/add-kindergardens/add-kindergardens.component';
import { DriverDetailsComponent } from './components/driver-details/driver-details.component';
import { DriverInlayComponent } from './components/driver-inlay/driver-inlay.component';
import { DriverUpdateComponent } from './components/drivers-update/drivers-update.component';
import { DriversComponent } from './components/drivers/drivers.component';
import { KindergardenUpdateComponent } from './components/kindergarden-update/kindergarden-update.component';
import { KindergardensComponent } from './components/kindergardens/kindergardens.component';
import { LoginComponent } from './components/login/login.component';
import { MessageComponent } from './components/message/message.component';
import { SystemInlayComponent } from './components/system-inlay/system-inlay.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'system-inlay', component: SystemInlayComponent },
  { path: 'message', component: MessageComponent },
  { path: 'add-driver', component: AddDriverComponent },
  { path: 'drivers', component: DriversComponent },
  { path: 'add-kindergardens', component: AddKindergardensComponent },
  { path: 'driver-details', component: DriverDetailsComponent },
  { path: 'driver-inlay', component: DriverInlayComponent },
  { path: 'kindergarden-update', component: KindergardenUpdateComponent },
  { path: 'kindergarden', component: KindergardensComponent },
  { path: 'drivers', component: DriversComponent },
  { path: 'drivers_update', component: DriverUpdateComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {




}
