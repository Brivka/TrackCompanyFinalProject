﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class UserDTO
    {
        
        public DriverDTO Driver { get; set; }
        public SystemDirectorDTO SystemDirector { get; set; }

    }

}
