﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class InlayDTO
    {
        public int IdInlay { get; set; }
        public int IdDriver { get; set; }
        public string NameDriver { get; set; }
        public int IdKindergarden { get; set; }
        public int numberKindergarden { get; set; }
        public KindergardensDTO kindergardens { get; set; }
    }
}
