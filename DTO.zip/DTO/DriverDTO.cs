﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DriverDTO
    {
        public int IdDriver { get; set; }
        public string firstNameDriver { get; set; }
        public string lastNameDriver { get; set; }
        public string phoneDriver { get; set; }
        public string emailDriver { get; set; }
        public string addressDriver { get; set; }
        public string passwordDriver { get; set; }
        public string trustPasswordDriver { get; set; }
        public int containInCar { get; set; }
        public TimeSpan startTime { get; set; }
        public TimeSpan endTime { get; set; }
    }
}
