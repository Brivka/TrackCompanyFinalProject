﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace DTO
{
    public class KindergardensDTO
    {
        public int IdKindergarden { get; set; }
        public string kindergardenName { get; set; }
        public string KindergartensGroup { get; set; }
        public string addressKindergarden { get; set; }
        public string phoneKindergarden { get; set; }
        public System.TimeSpan lunchTime { get; set; }
        public int amountFoodInKindergarden { get; set; }
    }
}
