﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class MessageDTO
    {
        public int IdMessages { get; set; }
        public int IdDriver { get; set; }
        public int IdSystemDirector { get; set; }
        public System.DateTime dateMessages { get; set; }
        public string contentMessages { get; set; }
        public string responseMessages { get; set; }
        public bool statusMessages { get; set; }
    }
}
