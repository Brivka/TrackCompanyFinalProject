﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class SupplyPlaceDTO
    {
        public int IdSupply { get; set; }
        public string supplyName { get; set; }
        public string phoneSupply { get; set; }
        public string addressSupply { get; set; }
    }
}
