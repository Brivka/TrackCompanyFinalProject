﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class SystemDirectorDTO
    {
        public int IdSystemDirector { get; set; }
        public int IdSupply { get; set; }
        public string passwordSystem { get; set; }
        public string trustPasswordSystem { get; set; }
        public string emailSystem { get; set; }
        public string phoneSystem { get; set; }
    }
}
